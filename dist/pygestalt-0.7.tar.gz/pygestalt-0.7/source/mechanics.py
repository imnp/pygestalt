#   pyGestalt Mechanics Module

"""A set of objects and methods for defining, analyzing, and utilizing mechanisms."""

#---- INCLUDES ----
import math
from pygestalt import errors



# class matrix(object):
#     """A base class for creating transformation matrices."""
#     def __init__(self, array):
#         self.array = array
# 
#     def forward(self, input):
#         if self.array[1][1]
#     
# class transformer(object):
#     def __init__(self):
#         self.transformMatrix = matrix([[1,2],[3,4]])
